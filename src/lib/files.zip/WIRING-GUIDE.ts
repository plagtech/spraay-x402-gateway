// ============================================================
// 💧 WIRING GUIDE — 3 New Endpoints
// ============================================================
// Copy the relevant lines into your index.ts and pricing.ts.
// Token Safety + Address Safety = FREE (no pricing entry needed)
// Trust Score = PAID ($0.03)
// ============================================================

// ---- 1. IMPORTS (add near top of index.ts with the other route imports) ----

import { tokenSafetyHandler } from "./routes/tokenSafety.js";
import { addressSafetyHandler } from "./routes/addressSafety.js";
import { trustScoreHandler } from "./routes/trustScore.js";


// ---- 2. PAYMENT MIDDLEWARE — Trust Score ONLY (add inside paymentMiddleware config) ----
// Token Safety and Address Safety are FREE — do NOT add them here.

      "GET /api/v1/trust/score": {
        accepts: [
          { scheme: "exact", price: "$0.03", network: CAIP2_NETWORK, payTo: PAY_TO },
          { scheme: "exact", price: "$0.03", network: SOLANA_NETWORK, payTo: SOLANA_PAY_TO },
        ],
        description: "Multi-dimensional wallet/agent trust score via ProofLayer. Financial, reliability, trust, social axes + XMTP reputation + on-chain signals.",
        mimeType: "application/json",
        extensions: {
          ...declareDiscoveryExtension({
            input: { address: "0x..." },
            inputSchema: {
              properties: { address: { type: "string" } },
              required: ["address"],
            },
            output: {
              example: { overall: 72, verdict: "Trusted", tier: "Silver", breakdown: { financial: 70, reliability: 70, trust: 80, social: 66 } },
              schema: {
                properties: {
                  overall: { type: "number" },
                  verdict: { type: "string" },
                  tier: { type: "string" },
                  breakdown: { type: "object" },
                },
              },
            },
          }),
        },
      },


// ---- 3. ROUTE MOUNTING ----

// Trust Score — PAID (mounted BEFORE the // FREE ROUTES section, alongside other paid routes)
app.get("/api/v1/trust/score", trustScoreHandler);

// Token Safety + Address Safety — FREE (mount in the // FREE ROUTES section, after line 1062)
// These are NOT in the paymentMiddleware config, so the payment gate skips them.
app.get("/api/v1/token/safety", tokenSafetyHandler);
app.get("/api/v1/address/safety", addressSafetyHandler);


// ---- 4. .well-known/x402.json RESOURCES ARRAY ----
// Add these entries to the resources array inside the x402.json handler:

      // Free — Token Safety
      { resource: `${BASE_URL}/api/v1/token/safety`, method: "GET", price: "free", category: "defi", description: "Free pre-trade token safety check — honeypot, sell tax, mint/blacklist, proxy risk. GoPlus-powered with Spraay severity scoring. Called before every trade.", searchTerms: ["token safety","honeypot","scam check","sell tax","rug pull","token security","is it safe","can I sell","buy tax","token risk"] },
      // Free — Address Safety
      { resource: `${BASE_URL}/api/v1/address/safety`, method: "GET", price: "free", category: "payments", description: "Free address safety screen — phishing, sanctions, exploits, mixer usage, malicious contracts. Screen recipients before sending funds.", searchTerms: ["address safety","malicious address","phishing","sanctions check","wallet check","is address safe","recipient check","AML","scam address","blacklist"] },
      // Paid — Trust Score
      { resource: `${BASE_URL}/api/v1/trust/score`, method: "GET", price: "$0.03", category: "trust", description: "Multi-dimensional wallet/agent trust score via ProofLayer. Financial, reliability, trust, social axes + XMTP reputation + on-chain signals. Counterparty due diligence for agent-to-agent payments.", searchTerms: ["trust score","wallet reputation","agent trust","counterparty check","ProofLayer","wallet score","agent reputation","due diligence","XMTP reputation","wallet risk"] },


// ---- 5. PRICING.TS — Trust Score ONLY ----
// Add to ENDPOINT_PRICES in pricing.ts (GoPlus endpoints are free, skip them):

  // ---- Trust / Reputation ----
  "GET /api/v1/trust/score":               { price: "0.03",  category: "trust" },


// ---- 6. BOOT LOG (optional — update the line count in app.listen) ----
// Change: console.log(`\n🌐 139 paid endpoints live across 36 categories\n`);
// To:     console.log(`\n🌐 140 paid endpoints live across 37 categories\n`);
// (139 + 1 paid trust endpoint = 140; "trust" is a new category)
// Plus 2 new free endpoints (token safety + address safety).


// ---- 7. FILES TO PLACE ----
// tokenSafety.ts   → src/routes/tokenSafety.ts
// addressSafety.ts → src/routes/addressSafety.ts
// trustScore.ts    → src/routes/trustScore.ts
